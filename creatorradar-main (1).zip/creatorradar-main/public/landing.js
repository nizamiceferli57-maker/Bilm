const modalRoot = document.getElementById("modal-root");
const authForm = document.getElementById("auth-form");
const formError = document.getElementById("form-error");
const authSubmit = document.getElementById("auth-submit");
const fieldLogin = document.getElementById("field-login");
const fieldPassword = document.getElementById("field-password");
const isLandingHome = Boolean(document.querySelector(".hero"));

async function api(path, body) {
  const response = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "same-origin",
    body: JSON.stringify(body || {}),
    cache: "no-store",
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || `Request failed (${response.status})`);
  }
  return data;
}

function openModal() {
  if (!modalRoot) return;
  modalRoot.classList.remove("hidden");
  modalRoot.hidden = false;
  if (formError) {
    formError.classList.add("hidden");
    formError.textContent = "";
  }
  fieldLogin?.focus();
}

function closeModal() {
  if (!modalRoot) return;
  modalRoot.classList.add("hidden");
  modalRoot.hidden = true;
  authForm?.reset();
  if (formError) formError.classList.add("hidden");
}

if (modalRoot) {
  document.querySelectorAll("[data-open='login']").forEach((btn) => {
    btn.addEventListener("click", () => openModal());
  });

  document.querySelectorAll("[data-close]").forEach((el) => {
    el.addEventListener("click", closeModal);
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !modalRoot.hidden) closeModal();
  });
}

if (authForm && authSubmit && fieldLogin && fieldPassword && formError) {
  authForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    formError.classList.add("hidden");
    authSubmit.disabled = true;
    const prev = authSubmit.textContent;
    authSubmit.textContent = "Working…";

    try {
      const result = await api("/api/auth/login", {
        login: fieldLogin.value,
        password: fieldPassword.value,
      });
      window.location.href = result.user?.role === "admin" ? "/admin" : "/app";
    } catch (error) {
      formError.textContent = error.message || "Something went wrong.";
      formError.classList.remove("hidden");
      authSubmit.disabled = false;
      authSubmit.textContent = prev;
    }
  });
}

async function boot() {
  if (isLandingHome) {
    try {
      const res = await fetch("/api/auth/me", {
        credentials: "same-origin",
        cache: "no-store",
      });
      const data = await res.json().catch(() => ({}));
      if (data.user) {
        window.location.href = data.user.role === "admin" ? "/admin" : "/app";
        return;
      }
    } catch {
      // stay on landing
    }
  }

  const params = new URLSearchParams(window.location.search);
  if (params.get("login") === "1" || params.get("admin") === "1") openModal();
}

boot();

(function initEarlyAccessForm() {
  const form = document.getElementById("early-access-form");
  const wrap = document.getElementById("early-access-form-wrap");
  const thanks = document.getElementById("early-access-thanks");
  const errorEl = document.getElementById("ea-error");
  const submitBtn = document.getElementById("ea-submit");
  const nameEl = document.getElementById("ea-name");
  const emailEl = document.getElementById("ea-email");
  const orgEl = document.getElementById("ea-organization");
  const reasonEl = document.getElementById("ea-reason");
  const reasonCountEl = document.getElementById("ea-reason-count");
  if (!form || !wrap || !thanks || !submitBtn || !nameEl || !emailEl || !orgEl || !reasonEl) {
    return;
  }

  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const MIN_ORG = 2;
  const MAX_ORG = 120;
  const MIN_REASON = 50;
  const MAX_REASON = 500;

  function reasonLength() {
    return (reasonEl.value || "").trim().length;
  }

  function updateReasonCount() {
    if (!reasonCountEl) return;
    const len = reasonLength();
    const remaining = MIN_REASON - len;
    reasonCountEl.classList.remove("is-short", "is-ok", "is-max");

    if (len >= MAX_REASON) {
      reasonCountEl.textContent = `${len} / ${MAX_REASON}`;
      reasonCountEl.classList.add("is-max");
    } else if (remaining > 0) {
      reasonCountEl.textContent =
        remaining === MIN_REASON
          ? `0 / ${MIN_REASON} minimum`
          : `${len} / ${MIN_REASON} minimum · ${remaining} more needed`;
      reasonCountEl.classList.add("is-short");
    } else {
      reasonCountEl.textContent = `OK · ${len} / ${MAX_REASON}`;
      reasonCountEl.classList.add("is-ok");
    }
  }

  function clearFieldErrors() {
    [nameEl, emailEl, orgEl, reasonEl].forEach((el) => {
      el.classList.remove("is-invalid");
      el.removeAttribute("aria-invalid");
    });
    errorEl.classList.add("hidden");
    errorEl.textContent = "";
  }

  function markInvalid(el) {
    el.classList.add("is-invalid");
    el.setAttribute("aria-invalid", "true");
  }

  function validateClient() {
    clearFieldErrors();
    const name = (nameEl.value || "").trim();
    const email = (emailEl.value || "").trim();
    const organization = (orgEl.value || "").trim();
    const reason = (reasonEl.value || "").trim();
    const problems = [];

    if (!name) {
      problems.push("Name is required.");
      markInvalid(nameEl);
    }
    if (!email) {
      problems.push("Email is required.");
      markInvalid(emailEl);
    } else if (!EMAIL_RE.test(email)) {
      problems.push("Please enter a valid email address.");
      markInvalid(emailEl);
    }
    if (!organization) {
      problems.push("Network / Agency / Team is required.");
      markInvalid(orgEl);
    } else if (organization.length < MIN_ORG) {
      problems.push("Please enter a valid Network / Agency / Team name.");
      markInvalid(orgEl);
    }
    if (!reason) {
      problems.push("Please tell us why you want access.");
      markInvalid(reasonEl);
    } else if (reason.length < MIN_REASON) {
      problems.push(
        `Please tell us briefly why you want access (at least ${MIN_REASON} characters).`
      );
      markInvalid(reasonEl);
    }

    if (problems.length) {
      errorEl.textContent = problems.join(" ");
      errorEl.classList.remove("hidden");
      const firstInvalid = form.querySelector(".is-invalid");
      firstInvalid?.focus();
      return null;
    }

    return {
      name,
      email,
      organization: organization.slice(0, MAX_ORG),
      reason: reason.slice(0, MAX_REASON),
      website: document.getElementById("ea-website")?.value || "",
    };
  }

  [nameEl, emailEl, orgEl, reasonEl].forEach((el) => {
    el.addEventListener("input", () => {
      if (el.classList.contains("is-invalid") && (el.value || "").trim()) {
        if (el === orgEl && (orgEl.value || "").trim().length < MIN_ORG) return;
        if (el === reasonEl && reasonLength() < MIN_REASON) return;
        el.classList.remove("is-invalid");
        el.removeAttribute("aria-invalid");
      }
    });
  });

  reasonEl.addEventListener("input", updateReasonCount);
  updateReasonCount();

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const payload = validateClient();
    if (!payload) return;

    submitBtn.disabled = true;
    const prev = submitBtn.textContent;
    submitBtn.textContent = "Sending…";

    try {
      const response = await fetch("/api/early-access", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify(payload),
        cache: "no-store",
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data.error || `Request failed (${response.status})`);
      }
      wrap.classList.add("hidden");
      wrap.hidden = true;
      thanks.classList.remove("hidden");
      thanks.hidden = false;
      thanks.focus?.();
    } catch (error) {
      errorEl.textContent = error.message || "Something went wrong. Please try again.";
      errorEl.classList.remove("hidden");
      submitBtn.disabled = false;
      submitBtn.textContent = prev;
    }
  });
})();

(function initTesterAvatars() {
  document.querySelectorAll("[data-tester-avatar]").forEach((img) => {
    const avatar = img.closest(".tester-avatar");
    if (!avatar) return;

    function showFallback() {
      avatar.classList.add("is-fallback");
    }

    img.addEventListener("error", showFallback);
    if (img.complete && img.naturalWidth === 0) showFallback();
  });
})();

(function initBackToTop() {
  const btn = document.getElementById("back-to-top");
  if (!btn) return;

  const SHOW_AFTER = 420;
  let ticking = false;

  function updateVisibility() {
    const show = window.scrollY > SHOW_AFTER;
    btn.classList.toggle("is-visible", show);
    btn.hidden = !show;
    ticking = false;
  }

  function onScroll() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(updateVisibility);
  }

  btn.addEventListener("click", () => {
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
    btn.blur();
  });

  window.addEventListener("scroll", onScroll, { passive: true });
  updateVisibility();
})();
